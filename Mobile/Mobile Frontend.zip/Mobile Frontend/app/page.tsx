"use client"

import { useState, useEffect } from "react"
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd"
import { WeatherWidget } from "./components/weather-widget"
import { SensorReadings } from "./components/sensor-readings"
import { AlertsList } from "./components/alerts-list"
import { SensorGraphs } from "./components/sensor-graphs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Plus, X, GripVertical } from "lucide-react"

const rooms = [
  { value: "room1", label: "Room 1" },
  { value: "room2", label: "Room 2" },
  { value: "room3", label: "Room 3" },
]

const shelves = [
  { value: "shelfA", label: "Shelf A" },
  { value: "shelfB", label: "Shelf B" },
  { value: "shelfC", label: "Shelf C" },
]

const widgetTypes = [
  { value: "sensors", label: "Sensor Readings" },
  { value: "alerts", label: "Alerts" },
  { value: "weather", label: "Weather" },
  { value: "graphs", label: "Sensor Graphs" },
]

interface Widget {
  id: string
  type: string
  room?: string
  shelf?: string
}

export default function Home() {
  const [widgets, setWidgets] = useState<Widget[]>([])
  const [newWidgetType, setNewWidgetType] = useState("")
  const [newWidgetRoom, setNewWidgetRoom] = useState("")
  const [newWidgetShelf, setNewWidgetShelf] = useState("")

  useEffect(() => {
    const savedWidgets = localStorage.getItem("dashboardWidgets")
    if (savedWidgets) {
      setWidgets(JSON.parse(savedWidgets))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("dashboardWidgets", JSON.stringify(widgets))
  }, [widgets])

  const addWidget = () => {
    if (newWidgetType) {
      const newWidget: Widget = {
        id: `${newWidgetType}-${Date.now()}`,
        type: newWidgetType,
        ...(newWidgetRoom && { room: newWidgetRoom }),
        ...(newWidgetShelf && { shelf: newWidgetShelf }),
      }
      setWidgets([...widgets, newWidget])
      setNewWidgetType("")
      setNewWidgetRoom("")
      setNewWidgetShelf("")
    }
  }

  const removeWidget = (id: string) => {
    setWidgets(widgets.filter((widget) => widget.id !== id))
  }

  const renderWidget = (widget: Widget) => {
    switch (widget.type) {
      case "sensors":
        return <SensorReadings room={widget.room} shelf={widget.shelf} />
      case "alerts":
        return <AlertsList />
      case "weather":
        return <WeatherWidget />
      case "graphs":
        return <SensorGraphs room={widget.room} shelf={widget.shelf} />
      default:
        return null
    }
  }

  const onDragEnd = (result) => {
    if (!result.destination) {
      return
    }

    const items = Array.from(widgets)
    const [reorderedItem] = items.splice(result.source.index, 1)
    items.splice(result.destination.index, 0, reorderedItem)

    setWidgets(items)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Agrisense Dashboard</h1>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="icon">
              <Plus className="h-4 w-4" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80">
            <div className="space-y-4">
              <h2 className="font-semibold">Add Widget</h2>
              <Select value={newWidgetType} onValueChange={setNewWidgetType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select widget type" />
                </SelectTrigger>
                <SelectContent>
                  {widgetTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {(newWidgetType === "sensors" || newWidgetType === "graphs") && (
                <>
                  <Select value={newWidgetRoom} onValueChange={setNewWidgetRoom}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select room" />
                    </SelectTrigger>
                    <SelectContent>
                      {rooms.map((room) => (
                        <SelectItem key={room.value} value={room.value}>
                          {room.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={newWidgetShelf} onValueChange={setNewWidgetShelf}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select shelf" />
                    </SelectTrigger>
                    <SelectContent>
                      {shelves.map((shelf) => (
                        <SelectItem key={shelf.value} value={shelf.value}>
                          {shelf.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </>
              )}
              <Button onClick={addWidget} disabled={!newWidgetType}>
                Add Widget
              </Button>
            </div>
          </PopoverContent>
        </Popover>
      </div>
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="widgets">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {widgets.map((widget, index) => (
                <Draggable key={widget.id} draggableId={widget.id} index={index}>
                  {(provided) => (
                    <div ref={provided.innerRef} {...provided.draggableProps}>
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                          <CardTitle className="text-sm font-medium">
                            {widgetTypes.find((t) => t.value === widget.type)?.label}
                            {widget.room && widget.shelf && ` - ${widget.room}, ${widget.shelf}`}
                          </CardTitle>
                          <div className="flex items-center">
                            <Button variant="ghost" size="icon" onClick={() => removeWidget(widget.id)}>
                              <X className="h-4 w-4" />
                            </Button>
                            <div {...provided.dragHandleProps}>
                              <GripVertical className="h-4 w-4 cursor-move" />
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>{renderWidget(widget)}</CardContent>
                      </Card>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  )
}

