"use client"

import { useState } from "react"
import { SensorReadings } from "../components/sensor-readings"
import { SensorGraphs } from "../components/sensor-graphs"
import { SensorMenu } from "../components/sensor-menu"

export default function SensorsPage() {
  const [selection, setSelection] = useState({
    room: "room1",
    sensors: ["soilMoisture", "temperature", "lightIntensity", "humidity"],
  })

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Sensors</h1>
        <SensorMenu onSelectionChange={setSelection} />
      </div>
      <SensorReadings selectedSensors={selection.sensors} room={selection.room} />
      <SensorGraphs selectedSensors={selection.sensors} room={selection.room} />
    </div>
  )
}

