"use client"

import { useState } from "react"
import { Check, ChevronsUpDown } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Checkbox } from "@/components/ui/checkbox"
import { useRoomShelf } from "./room-shelf-selector"

const sensors = [
  { value: "soilMoisture", label: "Soil Moisture" },
  { value: "temperature", label: "Temperature" },
  { value: "lightIntensity", label: "Light Intensity" },
  { value: "humidity", label: "Humidity" },
]

export function SensorMenu() {
  const { room, setRoom, shelf, setShelf } = useRoomShelf()
  const [open, setOpen] = useState(false)
  const [selectedSensors, setSelectedSensors] = useState(sensors.map((s) => s.value))

  const toggleSensor = (value: string) => {
    setSelectedSensors((current) =>
      current.includes(value) ? current.filter((v) => v !== value) : [...current, value],
    )
  }

  return (
    <div className="w-full max-w-3xl mx-auto bg-white shadow-md rounded-lg p-4 mb-6">
      <h2 className="text-lg font-semibold mb-4">Sensor Selection</h2>
      <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" role="combobox" aria-expanded={open} className="w-[200px] justify-between">
              {room.label}
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[200px] p-0">
            <Command>
              <CommandInput placeholder="Search room..." />
              <CommandList>
                <CommandEmpty>No room found.</CommandEmpty>
                <CommandGroup>
                  {[
                    { value: "room1", label: "Room 1" },
                    { value: "room2", label: "Room 2" },
                    { value: "room3", label: "Room 3" },
                  ].map((item) => (
                    <CommandItem
                      key={item.value}
                      onSelect={() => {
                        setRoom(item)
                        setOpen(false)
                      }}
                    >
                      <Check className={cn("mr-2 h-4 w-4", room.value === item.value ? "opacity-100" : "opacity-0")} />
                      {item.label}
                    </CommandItem>
                  ))}
                </CommandGroup>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-[200px] justify-between">
              Sensors
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[200px] p-2">
            {sensors.map((sensor) => (
              <div key={sensor.value} className="flex items-center space-x-2">
                <Checkbox
                  id={sensor.value}
                  checked={selectedSensors.includes(sensor.value)}
                  onCheckedChange={() => toggleSensor(sensor.value)}
                />
                <label htmlFor={sensor.value}>{sensor.label}</label>
              </div>
            ))}
          </PopoverContent>
        </Popover>
      </div>
    </div>
  )
}

