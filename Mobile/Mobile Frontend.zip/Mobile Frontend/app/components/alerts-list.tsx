import { AlertTriangle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function AlertsList() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Alerts</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-4">
          <li className="flex items-center text-yellow-600">
            <AlertTriangle className="h-5 w-5 mr-2 flex-shrink-0" />
            <span>Low soil moisture in Sector A</span>
          </li>
          <li className="flex items-center text-red-600">
            <AlertTriangle className="h-5 w-5 mr-2 flex-shrink-0" />
            <span>High temperature in Greenhouse 2</span>
          </li>
        </ul>
      </CardContent>
    </Card>
  )
}

