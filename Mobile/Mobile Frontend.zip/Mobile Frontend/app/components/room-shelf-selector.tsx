"use client"

import { useState, createContext, useContext, type ReactNode } from "react"
import { Check, ChevronsUpDown } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

const rooms = [
  { value: "room1", label: "Room 1" },
  { value: "room2", label: "Room 2" },
  { value: "room3", label: "Room 3" },
]

const shelves = [
  { value: "shelfA", label: "Shelf A" },
  { value: "shelfB", label: "Shelf B" },
  { value: "shelfC", label: "Shelf C" },
]

interface RoomShelfContextType {
  room: { value: string; label: string }
  shelf: { value: string; label: string }
  setRoom: (room: { value: string; label: string }) => void
  setShelf: (shelf: { value: string; label: string }) => void
}

const RoomShelfContext = createContext<RoomShelfContextType | undefined>(undefined)

export function RoomShelfProvider({ children }: { children: ReactNode }) {
  const [room, setRoom] = useState(rooms[0])
  const [shelf, setShelf] = useState(shelves[0])

  return <RoomShelfContext.Provider value={{ room, shelf, setRoom, setShelf }}>{children}</RoomShelfContext.Provider>
}

export function useRoomShelf() {
  const context = useContext(RoomShelfContext)
  if (context === undefined) {
    throw new Error("useRoomShelf must be used within a RoomShelfProvider")
  }
  return context
}

export function RoomShelfSelector() {
  const { room, shelf, setRoom, setShelf } = useRoomShelf()
  const [openRoom, setOpenRoom] = useState(false)
  const [openShelf, setOpenShelf] = useState(false)

  return (
    <div className="flex space-x-4 mb-4">
      <Popover open={openRoom} onOpenChange={setOpenRoom}>
        <PopoverTrigger asChild>
          <Button variant="outline" role="combobox" aria-expanded={openRoom} className="w-[200px] justify-between">
            {room.label}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[200px] p-0">
          <Command>
            <CommandInput placeholder="Search room..." />
            <CommandList>
              <CommandEmpty>No room found.</CommandEmpty>
              <CommandGroup>
                {rooms.map((item) => (
                  <CommandItem
                    key={item.value}
                    onSelect={() => {
                      setRoom(item)
                      setOpenRoom(false)
                    }}
                  >
                    <Check className={cn("mr-2 h-4 w-4", room.value === item.value ? "opacity-100" : "opacity-0")} />
                    {item.label}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      <Popover open={openShelf} onOpenChange={setOpenShelf}>
        <PopoverTrigger asChild>
          <Button variant="outline" role="combobox" aria-expanded={openShelf} className="w-[200px] justify-between">
            {shelf.label}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[200px] p-0">
          <Command>
            <CommandInput placeholder="Search shelf..." />
            <CommandList>
              <CommandEmpty>No shelf found.</CommandEmpty>
              <CommandGroup>
                {shelves.map((item) => (
                  <CommandItem
                    key={item.value}
                    onSelect={() => {
                      setShelf(item)
                      setOpenShelf(false)
                    }}
                  >
                    <Check className={cn("mr-2 h-4 w-4", shelf.value === item.value ? "opacity-100" : "opacity-0")} />
                    {item.label}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  )
}

