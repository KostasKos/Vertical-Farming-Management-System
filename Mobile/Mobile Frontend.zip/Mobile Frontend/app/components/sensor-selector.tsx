"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

const rooms = ["Room 1", "Room 2", "Room 3"]
const shelves = ["Shelf A", "Shelf B", "Shelf C"]
const sensorTypes = ["Soil Moisture", "Temperature", "Light Intensity"]

export function SensorSelector({ onSelectionChange }: { onSelectionChange: (selection: any) => void }) {
  const [selectedRoom, setSelectedRoom] = useState(rooms[0])
  const [selectedShelf, setSelectedShelf] = useState(shelves[0])
  const [selectedSensors, setSelectedSensors] = useState(sensorTypes)

  const handleSensorToggle = (sensor: string) => {
    setSelectedSensors((prev) => (prev.includes(sensor) ? prev.filter((s) => s !== sensor) : [...prev, sensor]))
  }

  const updateSelection = () => {
    onSelectionChange({
      room: selectedRoom,
      shelf: selectedShelf,
      sensors: selectedSensors,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sensor Selection</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <Label htmlFor="room-select">Room</Label>
            <Select
              onValueChange={(value) => {
                setSelectedRoom(value)
                updateSelection()
              }}
            >
              <SelectTrigger id="room-select">
                <SelectValue placeholder="Select a room" />
              </SelectTrigger>
              <SelectContent>
                {rooms.map((room) => (
                  <SelectItem key={room} value={room}>
                    {room}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="shelf-select">Shelf</Label>
            <Select
              onValueChange={(value) => {
                setSelectedShelf(value)
                updateSelection()
              }}
            >
              <SelectTrigger id="shelf-select">
                <SelectValue placeholder="Select a shelf" />
              </SelectTrigger>
              <SelectContent>
                {shelves.map((shelf) => (
                  <SelectItem key={shelf} value={shelf}>
                    {shelf}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Sensors</Label>
            <div className="mt-2 space-y-2">
              {sensorTypes.map((sensor) => (
                <div key={sensor} className="flex items-center space-x-2">
                  <Checkbox
                    id={sensor}
                    checked={selectedSensors.includes(sensor)}
                    onCheckedChange={() => {
                      handleSensorToggle(sensor)
                      updateSelection()
                    }}
                  />
                  <Label htmlFor={sensor}>{sensor}</Label>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

