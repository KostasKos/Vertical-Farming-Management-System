import React from "react"

interface CircularGaugeProps {
  value: number
  max: number
  label: string
  size?: number
  strokeWidth?: number
}

export function CircularGauge({ value, max, label, size = 200, strokeWidth = 10 }: CircularGaugeProps) {
  const normalizedValue = (value / max) * 100
  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const strokeDashoffset = circumference - (normalizedValue / 100) * circumference

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle
          className="text-gray-200"
          strokeWidth={strokeWidth}
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
        <circle
          className="text-green-600"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
          style={{
            transformOrigin: "50% 50%",
            transform: "rotate(-90deg)",
            transition: "stroke-dashoffset 0.5s ease-in-out",
          }}
        />
        <text x="50%" y="50%" textAnchor="middle" fill="currentColor" className="font-bold text-3xl" dy=".3em">
          {value}
        </text>
      </svg>
      <span className="mt-2 text-gray-700">{label}</span>
    </div>
  )
}

