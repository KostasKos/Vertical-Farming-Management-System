import { Cloud, Droplets, Thermometer } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function WeatherWidget() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Weather</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
          <div className="flex items-center">
            <Thermometer className="h-5 w-5 mr-2 text-red-500" />
            <span>25°C</span>
          </div>
          <div className="flex items-center">
            <Droplets className="h-5 w-5 mr-2 text-blue-500" />
            <span>60%</span>
          </div>
          <div className="flex items-center">
            <Cloud className="h-5 w-5 mr-2 text-gray-500" />
            <span>Partly Cloudy</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

