"use client"

import { useRoomShelf } from "./room-shelf-selector"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const data = {
  room1: {
    shelfA: [
      { time: "00:00", soilMoisture: 40, temperature: 22, lightIntensity: 0, humidity: 55 },
      { time: "04:00", soilMoisture: 42, temperature: 21, lightIntensity: 0, humidity: 57 },
      { time: "08:00", soilMoisture: 45, temperature: 23, lightIntensity: 5000, humidity: 60 },
      { time: "12:00", soilMoisture: 43, temperature: 26, lightIntensity: 15000, humidity: 58 },
      { time: "16:00", soilMoisture: 41, temperature: 28, lightIntensity: 12000, humidity: 56 },
      { time: "20:00", soilMoisture: 44, temperature: 25, lightIntensity: 2000, humidity: 59 },
    ],
    shelfB: [
      { time: "00:00", soilMoisture: 45, temperature: 23, lightIntensity: 0, humidity: 58 },
      { time: "04:00", soilMoisture: 47, temperature: 22, lightIntensity: 0, humidity: 60 },
      { time: "08:00", soilMoisture: 50, temperature: 24, lightIntensity: 5500, humidity: 63 },
      { time: "12:00", soilMoisture: 48, temperature: 27, lightIntensity: 15500, humidity: 61 },
      { time: "16:00", soilMoisture: 46, temperature: 29, lightIntensity: 12500, humidity: 59 },
      { time: "20:00", soilMoisture: 49, temperature: 26, lightIntensity: 2500, humidity: 62 },
    ],
    shelfC: [
      { time: "00:00", soilMoisture: 42, temperature: 24, lightIntensity: 0, humidity: 56 },
      { time: "04:00", soilMoisture: 44, temperature: 23, lightIntensity: 0, humidity: 58 },
      { time: "08:00", soilMoisture: 47, temperature: 25, lightIntensity: 5200, humidity: 61 },
      { time: "12:00", soilMoisture: 45, temperature: 28, lightIntensity: 15200, humidity: 59 },
      { time: "16:00", soilMoisture: 43, temperature: 30, lightIntensity: 12200, humidity: 57 },
      { time: "20:00", soilMoisture: 46, temperature: 27, lightIntensity: 2200, humidity: 60 },
    ],
  },
  // Add similar data structures for room2 and room3
}

const colors = {
  soilMoisture: "#8884d8",
  temperature: "#82ca9d",
  lightIntensity: "#ffc658",
  humidity: "#ff8042",
}

const sensorLabels = {
  soilMoisture: "Soil Moisture",
  temperature: "Temperature",
  lightIntensity: "Light Intensity",
  humidity: "Humidity",
}

export function SensorGraphs() {
  const { room, shelf } = useRoomShelf()

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Sensor Data Over Time - {room.label}, {shelf.label}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data[room.value][shelf.value]}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Legend />
              {Object.keys(colors).map((sensor) => (
                <Line
                  key={sensor}
                  type="monotone"
                  dataKey={sensor}
                  stroke={colors[sensor]}
                  name={sensorLabels[sensor]}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

