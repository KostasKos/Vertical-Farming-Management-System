"use client"
import { CircularGauge } from "./circular-gauge"

interface SensorReadingsProps {
  room?: string
  shelf?: string
}

const sensorData = {
  room1: {
    shelfA: { soilMoisture: 45, temperature: 25, lightIntensity: 12000, humidity: 60 },
    shelfB: { soilMoisture: 50, temperature: 24, lightIntensity: 11000, humidity: 62 },
    shelfC: { soilMoisture: 48, temperature: 26, lightIntensity: 13000, humidity: 58 },
  },
  room2: {
    shelfA: { soilMoisture: 55, temperature: 23, lightIntensity: 10000, humidity: 65 },
    shelfB: { soilMoisture: 52, temperature: 22, lightIntensity: 9500, humidity: 67 },
    shelfC: { soilMoisture: 58, temperature: 24, lightIntensity: 10500, humidity: 63 },
  },
  room3: {
    shelfA: { soilMoisture: 40, temperature: 27, lightIntensity: 14000, humidity: 55 },
    shelfB: { soilMoisture: 42, temperature: 26, lightIntensity: 13500, humidity: 57 },
    shelfC: { soilMoisture: 38, temperature: 28, lightIntensity: 14500, humidity: 53 },
  },
}

const sensorConfig = {
  soilMoisture: { max: 100, unit: "%" },
  temperature: { max: 50, unit: "°C" },
  lightIntensity: { max: 20000, unit: "lux" },
  humidity: { max: 100, unit: "%" },
}

export function SensorReadings({ room = "room1", shelf = "shelfA" }: SensorReadingsProps) {
  const readings = sensorData[room][shelf]

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {Object.entries(readings).map(([sensor, value]) => (
          <CircularGauge
            key={sensor}
            value={value}
            max={sensorConfig[sensor].max}
            label={`${sensor} (${sensorConfig[sensor].unit})`}
            size={120}
            strokeWidth={8}
          />
        ))}
      </div>
    </div>
  )
}

