import Link from "next/link"
import { Home, Cpu, FileText, Settings } from "lucide-react"

export function BottomNav() {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
      <div className="flex justify-around items-center h-16">
        <Link href="/" className="flex flex-col items-center text-gray-600 hover:text-green-600">
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">Home</span>
        </Link>
        <Link href="/devices-sensors" className="flex flex-col items-center text-gray-600 hover:text-green-600">
          <Cpu className="h-6 w-6" />
          <span className="text-xs mt-1">Sensors</span>
        </Link>
        <Link href="/logs" className="flex flex-col items-center text-gray-600 hover:text-green-600">
          <FileText className="h-6 w-6" />
          <span className="text-xs mt-1">Logs</span>
        </Link>
        <Link href="/settings" className="flex flex-col items-center text-gray-600 hover:text-green-600">
          <Settings className="h-6 w-6" />
          <span className="text-xs mt-1">Settings</span>
        </Link>
      </div>
    </nav>
  )
}

