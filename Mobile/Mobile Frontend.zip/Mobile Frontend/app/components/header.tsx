import { Leaf } from "lucide-react"
import Link from "next/link"

export function Header() {
  return (
    <header className="border-b border-gray-200 bg-white/50 backdrop-blur-sm sticky top-0 z-10">
      <div className="container mx-auto flex h-14 items-center px-4 justify-center">
        <Link href="/" className="flex items-center gap-2 font-semibold text-green-600">
          <Leaf className="h-6 w-6" />
          <span className="text-lg">Agrisense</span>
        </Link>
      </div>
    </header>
  )
}

