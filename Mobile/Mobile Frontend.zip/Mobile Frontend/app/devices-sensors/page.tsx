"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Battery, Signal, Thermometer, Droplet, Sun, Wind } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const rooms = ["room1", "room2", "room3"]
const shelves = ["shelfA", "shelfB", "shelfC"]

const sensorData = {
  room1: {
    shelfA: { soilMoisture: 45, temperature: 25, lightIntensity: 12000, humidity: 60 },
    shelfB: { soilMoisture: 50, temperature: 24, lightIntensity: 11000, humidity: 62 },
    shelfC: { soilMoisture: 48, temperature: 26, lightIntensity: 13000, humidity: 58 },
  },
  room2: {
    shelfA: { soilMoisture: 55, temperature: 23, lightIntensity: 10000, humidity: 65 },
    shelfB: { soilMoisture: 52, temperature: 22, lightIntensity: 9500, humidity: 67 },
    shelfC: { soilMoisture: 58, temperature: 24, lightIntensity: 10500, humidity: 63 },
  },
  room3: {
    shelfA: { soilMoisture: 40, temperature: 27, lightIntensity: 14000, humidity: 55 },
    shelfB: { soilMoisture: 42, temperature: 26, lightIntensity: 13500, humidity: 57 },
    shelfC: { soilMoisture: 38, temperature: 28, lightIntensity: 14500, humidity: 53 },
  },
}

export default function DevicesAndSensors() {
  const [selectedRoom, setSelectedRoom] = useState(rooms[0])
  const [selectedShelf, setSelectedShelf] = useState(shelves[0])

  const sensorValues = sensorData[selectedRoom][selectedShelf]

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Devices & Sensors</h1>
      <div className="space-y-4">
        <Select onValueChange={setSelectedRoom} defaultValue={selectedRoom}>
          <SelectTrigger>
            <SelectValue placeholder="Select Room" />
          </SelectTrigger>
          <SelectContent>
            {rooms.map((room) => (
              <SelectItem key={room} value={room}>
                {room}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select onValueChange={setSelectedShelf} defaultValue={selectedShelf}>
          <SelectTrigger>
            <SelectValue placeholder="Select Shelf" />
          </SelectTrigger>
          <SelectContent>
            {shelves.map((shelf) => (
              <SelectItem key={shelf} value={shelf}>
                {shelf}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Soil Moisture Sensor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Status: Active</span>
                <Signal className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex justify-between items-center">
                <span>Battery: 75%</span>
                <Battery className="h-5 w-5 text-yellow-500" />
              </div>
              <div className="flex justify-between items-center">
                <span>Reading: {sensorValues.soilMoisture}%</span>
                <Droplet className="h-5 w-5 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Temperature Sensor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Status: Active</span>
                <Signal className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex justify-between items-center">
                <span>Battery: 80%</span>
                <Battery className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex justify-between items-center">
                <span>Reading: {sensorValues.temperature}°C</span>
                <Thermometer className="h-5 w-5 text-red-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Light Intensity Sensor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Status: Active</span>
                <Signal className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex justify-between items-center">
                <span>Battery: 90%</span>
                <Battery className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex justify-between items-center">
                <span>Reading: {sensorValues.lightIntensity} lux</span>
                <Sun className="h-5 w-5 text-yellow-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Humidity Sensor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Status: Active</span>
                <Signal className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex justify-between items-center">
                <span>Battery: 85%</span>
                <Battery className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex justify-between items-center">
                <span>Reading: {sensorValues.humidity}%</span>
                <Wind className="h-5 w-5 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

