"use client"

import "./globals.css"
import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Inter } from "next/font/google"
import { Header } from "./components/header"
import { BottomNav } from "./components/bottom-nav"
import { RoomShelfProvider } from "./components/room-shelf-selector"
import type React from "react"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    const checkLoginStatus = () => {
      const loggedIn = localStorage.getItem("isLoggedIn") === "true"
      setIsLoggedIn(loggedIn)
      if (!loggedIn && pathname !== "/login") {
        router.push("/login")
      }
    }

    checkLoginStatus()
    window.addEventListener("storage", checkLoginStatus)

    return () => {
      window.removeEventListener("storage", checkLoginStatus)
    }
  }, [router, pathname])

  if (!isLoggedIn && pathname !== "/login") {
    return null // Don't render anything while redirecting
  }

  return (
    <html lang="en">
      <body className={inter.className}>
        <RoomShelfProvider>
          <div className="flex flex-col min-h-screen bg-gray-100">
            {isLoggedIn && <Header />}
            <main className="flex-1 container mx-auto p-4 mb-16">{children}</main>
            {isLoggedIn && <BottomNav />}
          </div>
        </RoomShelfProvider>
      </body>
    </html>
  )
}



import './globals.css'
