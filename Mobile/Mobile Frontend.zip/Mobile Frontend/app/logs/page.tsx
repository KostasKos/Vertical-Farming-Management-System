"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, CheckCircle, Info, Clock, AlertCircle } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type LogType = "info" | "warning" | "error" | "success"

interface Log {
  id: number
  message: string
  type: LogType
  timestamp: string
  importance: "low" | "medium" | "high"
}

const dummyLogs: Log[] = [
  {
    id: 1,
    message: "System startup completed",
    type: "info",
    timestamp: "2023-07-26 08:00",
    importance: "low",
  },
  {
    id: 2,
    message: "Temperature in Room 1 exceeds threshold",
    type: "warning",
    timestamp: "2023-07-26 10:15",
    importance: "medium",
  },
  {
    id: 3,
    message: "Irrigation system activated in Sector A",
    type: "success",
    timestamp: "2023-07-26 11:30",
    importance: "low",
  },
  {
    id: 4,
    message: "Sensor malfunction detected in Room 2, Shelf B",
    type: "error",
    timestamp: "2023-07-26 14:45",
    importance: "high",
  },
  {
    id: 5,
    message: "Daily system health check completed",
    type: "info",
    timestamp: "2023-07-26 23:00",
    importance: "low",
  },
]

export default function Logs() {
  const [logs, setLogs] = useState<Log[]>([])
  const [newLog, setNewLog] = useState("")
  const [newLogType, setNewLogType] = useState<LogType>("info")
  const [newLogImportance, setNewLogImportance] = useState<"low" | "medium" | "high">("low")

  useEffect(() => {
    const savedLogs = localStorage.getItem("agrisenseLogs")
    if (savedLogs) {
      setLogs(JSON.parse(savedLogs))
    } else {
      setLogs(dummyLogs)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("agrisenseLogs", JSON.stringify(logs))
  }, [logs])

  const addLog = () => {
    if (newLog.trim() !== "") {
      const currentTime = new Date().toLocaleString()
      setLogs([
        ...logs,
        {
          id: logs.length + 1,
          message: newLog,
          type: newLogType,
          timestamp: currentTime,
          importance: newLogImportance,
        },
      ])
      setNewLog("")
      setNewLogType("info")
      setNewLogImportance("low")
    }
  }

  const getIcon = (type: LogType) => {
    switch (type) {
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0" />
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
      case "info":
        return <Info className="h-5 w-5 text-blue-500 flex-shrink-0" />
      case "error":
        return <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Logs</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button>Create New Log</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Log</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input value={newLog} onChange={(e) => setNewLog(e.target.value)} placeholder="Enter log message" />
              <Select value={newLogType} onValueChange={(value: LogType) => setNewLogType(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select log type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={newLogImportance}
                onValueChange={(value: "low" | "medium" | "high") => setNewLogImportance(value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select importance" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={addLog}>Add Log</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-4">
            {logs.map((log) => (
              <li key={log.id} className="flex items-center">
                {getIcon(log.type)}
                <div className="ml-2">
                  <span className="font-medium">{log.message}</span>
                  <div className="text-sm text-gray-500">
                    <Clock className="inline-block h-4 w-4 mr-1" />
                    {log.timestamp} | Importance: {log.importance}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

